﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Vella.Events.Tests")]
